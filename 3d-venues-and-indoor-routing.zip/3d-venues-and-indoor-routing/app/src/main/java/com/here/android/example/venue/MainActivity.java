package com.here.android.example.venue;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.here.android.mpa.venues3d.Venue;

public class MainActivity extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main_menu);

        final Button checkNearby = findViewById(R.id.checkNearby);
        checkNearby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //goes to map with people's listings
                startActivity(new Intent(MainActivity.this, Venue3dActivity.class));
            }
        });

        final Button checkAccount = findViewById(R.id.checkBadges);
        checkAccount.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
            }
        });

        final Button postListings = findViewById(R.id.postListings);
        postListings.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //goes to map with the postable items open
                startActivity(new Intent(MainActivity.this, CreateListings.class));
            }
        });
    }
}
